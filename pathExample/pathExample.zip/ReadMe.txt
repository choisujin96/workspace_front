./pathExample/exam\html
gang.jpg	-->절대경로, 상대경로
kim.jpg 	-->절대경로, 상대경로
jeon.jpg 	-->절대경로, 상대경로


./pathExample/yang\html/yang.html
yang.jpg	-->상대경로


./pathExample/jung.html
jung.jpg	-->상대경로


./pathExample/kwang.html
kwang.jpg	-->상대경로


./pathExample/park/park.html
park.jpg	-->상대경로


./pathExample/song/html/song.html
song.jpg	-->상대경로


./pathExample/you.html
you.jpg	-->상대경로